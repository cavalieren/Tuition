package fee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import fee.bean.Manager;
import fee.util.DbConnect;

public class ManagerDAO {

	public boolean save(Manager mana){ 
		String saveSql="insert into manager(mname,mpassword) values(?,?)";
		PreparedStatement ps;
		Connection conn;
		
		try{
			conn=DbConnect.getDBconnection();
			ps=conn.prepareStatement(saveSql);
			ps.setString(1,new String(mana.getMname().getBytes("iso8859_1"),"UTF-8"));
			ps.setString(2,mana.getMpassword());			
			int n=ps.executeUpdate();
			System.out.println("save:n="+n);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
 	public List<Manager> queryAllManager(){
 		String sql="select * from manager";
 		Connection conn=DbConnect.getDBconnection();
 		ArrayList<Manager> alu=new ArrayList<Manager>();
 		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Manager u=new Manager();
				u.setId(rs.getInt("id"));
				u.setMname(rs.getString("mname"));
				u.setMpassword(rs.getString("mpassword"));
				
				System.out.println("name="+u.getMname());
				alu.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);
			return alu;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}	
 	}
 	
 	public Manager queryManagerByName(String mname){
		String sql="select * from manager where mname=?";
		Connection conn;
		conn=DbConnect.getDBconnection();
		
		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, mname);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){
				Manager u=new Manager();
				u.setId(rs.getInt("id"));
				u.setMname(rs.getString("mname"));
				u.setMpassword(rs.getString("mpassword"));
				
				DbConnect.closeDB(conn, pstmt, rs);
				 return u;	
			}else
			 {return null;}
		}catch(Exception e){
			e.printStackTrace();
			return null;	
		}
	}
 	public List<Manager> queryAllManager1(){
 		String sql="select id,mname from manager";
 		Connection conn=DbConnect.getDBconnection();
 		ArrayList<Manager> alu=new ArrayList<Manager>();
 		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Manager u=new Manager();
				u.setId(rs.getInt("id"));
				u.setMname(rs.getString("mname"));
				
				alu.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);
			
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}	
 		return alu;
 	}
 	public Manager queryById(int id){
		String sql="select * from manager where id=?";
		Connection conn;
		//List<Manager> lc=new  ArrayList<Manager>();
		conn=DbConnect.getDBconnection();
		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){
				Manager c=new Manager();
				c.setId(rs.getInt("id"));
				c.setMname(rs.getString("mname"));
				c.setMpassword(rs.getString("mpassword"));
				
				DbConnect.closeDB(conn, pstmt, rs);
				return c; 	
			}else
			 {return null;}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
    public boolean delete(Manager c){ 
		
		try{ 
			String sql="delete from manager where id=?";
			Connection conn=DbConnect.getDBconnection();
			PreparedStatement ps=conn.prepareStatement(sql);	
			ps.setInt(1,c.getId() );
			int n=ps.executeUpdate();
			DbConnect.closeDB(conn, ps, null);
			System.out.println("delete:n="+n);
		}catch(Exception e){
			return false;
		}
		return true;
	}	
	
}
