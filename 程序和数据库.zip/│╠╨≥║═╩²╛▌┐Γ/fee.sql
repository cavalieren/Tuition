/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : fee

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2017-05-25 08:16:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `apartment`
-- ----------------------------
DROP TABLE IF EXISTS `apartment`;
CREATE TABLE `apartment` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `sno` varchar(11) DEFAULT NULL,
  `sname` varchar(50) DEFAULT NULL,
  `shouldpay` float(20,0) DEFAULT NULL,
  `paid` float(20,0) DEFAULT NULL,
  `sinstitution` varchar(50) DEFAULT NULL,
  `sgrade` varchar(20) DEFAULT NULL,
  `sclasss` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of apartment
-- ----------------------------
INSERT INTO `apartment` VALUES ('1', '13100140229', '姜金灼', '800', '700', '计算机学院', '大四', '一班');
INSERT INTO `apartment` VALUES ('2', '13100140230', '李四', '800', '0', '计算机学院', '大四', '一班');

-- ----------------------------
-- Table structure for `manager`
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `mname` varchar(50) NOT NULL,
  `mpassword` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('1', 'm1', '123456');
INSERT INTO `manager` VALUES ('2', 'm2', '123456');

-- ----------------------------
-- Table structure for `news`
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(500) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', '我校一般专业学费标准是4000-6000元/生', '2017-04-29 23:08');
INSERT INTO `news` VALUES ('2', '中外合作办学专业学费标准是16500元/生', '2017-04-11');
INSERT INTO `news` VALUES ('3', '体育、艺术专业学费标准最高不超9000元/生', '2017-04-11');
INSERT INTO `news` VALUES ('4', '住宿费600-1200元/生', '2017-04-11');
INSERT INTO `news` VALUES ('5', '黑龙江省将对公办普通高校本科学费标准进行规范和调整，目前正在按照国家规定程序办理，学费执行标准以黑龙江省教育厅、黑龙江省物价局、黑龙江省财政厅最新批复批准为准。', '2017-04-11');
INSERT INTO `news` VALUES ('6', '学校设有国家奖学金、学校综合奖学金、学校单项奖学金，对贫困学生设有国家励志奖学金、国家助学金、国家助学贷款、校友及社会奖助学金。', '2017-04-11');
INSERT INTO `news` VALUES ('7', '数学系收费标准请参见学校网站！', '2017-04-11');

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `sno` varchar(11) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `spassword` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sidcard` varchar(18) DEFAULT NULL,
  `sbankcard` varchar(19) DEFAULT NULL,
  `sinstitution` varchar(100) DEFAULT NULL,
  `sgrade` varchar(50) DEFAULT NULL,
  `sclasss` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '13100140229', '姜金灼', '140229', '230621199512280328', '6227001020910201888', '计算机学院', '大四', '一班');
INSERT INTO `student` VALUES ('2', '13100140230', '李四', '140230', '412326199502018762', '6228480712322134564', '计算机学院', '大四', '一班');
INSERT INTO `student` VALUES ('3', '13100140231', '王五', '140231', '412326199502218762', '6228480712322134522', '数学系', '大四', '二班');

-- ----------------------------
-- Table structure for `tuition`
-- ----------------------------
DROP TABLE IF EXISTS `tuition`;
CREATE TABLE `tuition` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `sno` varchar(11) DEFAULT NULL,
  `sname` varchar(50) DEFAULT NULL,
  `shouldpay` float(20,0) DEFAULT NULL,
  `paid` float(20,0) DEFAULT NULL,
  `sinstitution` varchar(100) DEFAULT NULL,
  `sgrade` varchar(50) DEFAULT NULL,
  `sclasss` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tuition
-- ----------------------------
INSERT INTO `tuition` VALUES ('1', '13100140229', '姜金灼', '6000', '6000', '计算机学院', '大四', '一班');
INSERT INTO `tuition` VALUES ('2', '13100140230', '李四', '6000', '0', '计算机学院', '大四', '一班');
