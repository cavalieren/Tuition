package fee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import fee.bean.Apartment2;
import fee.bean.Student1;
import fee.bean.Tuition1;
import fee.util.DbConnect;

public class ApartmentDAO {
	
	public boolean save(Apartment2 t) {
		String saveSql="insert into apartment(sno,sname,shouldpay,paid,sinstitution,sgrade,sclasss) "
				+ "values(?,?,?,?,?,?,?)";
		PreparedStatement ps;
		Connection conn;
		
		try{
			conn=DbConnect.getDBconnection();
			ps=conn.prepareStatement(saveSql);
			ps.setString(1,t.getSno());
			ps.setString(2,t.getSname());
			ps.setFloat(3, t.getShouldpay());
			ps.setFloat(4,t.getPaid());
			ps.setString(5, t.getSinstitution());
			ps.setString(6, t.getSgrade());
			ps.setString(7, t.getSclasss());
			int n=ps.executeUpdate();
			System.out.println("save:n="+n);
		}catch(Exception e){
			//e.printStackTrace();
			return false;
		}
		return true;

	}
	
	public List<Apartment2> queryAllApartment(){
 		String sql="select * from apartment";
 		Connection conn=DbConnect.getDBconnection();
 		ArrayList<Apartment2> alu=new ArrayList<Apartment2>();
 		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Apartment2 u=new Apartment2();
				u.setSno(rs.getString("sno"));
				u.setSname(rs.getString("sname"));	
				u.setShouldpay(rs.getFloat("shouldpay"));
				u.setPaid(rs.getFloat("paid"));
				u.setSinstitution(rs.getString("sinstitution"));
				u.setSgrade(rs.getString("sgrade"));
				u.setSclasss(rs.getString("sclasss"));
				alu.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);
			return alu;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}	
 	}
	
	public boolean delete(Apartment2 s){ 
		
		try{
			String sql="delete from apartment where sno=?";
			Connection conn=DbConnect.getDBconnection();
			PreparedStatement ps=conn.prepareStatement(sql);	
			ps.setString(1,s.getSno() );
			int n=ps.executeUpdate();
			DbConnect.closeDB(conn, ps, null);
			System.out.println("delete:n="+n);
		}catch(Exception e){
			return false;
		}
		return true;
	}	
	
	public Apartment2 querybynoname(String sno,String sname){//组合查询
		
		String sql="select * from apartment where sno=? and sname=?";
			Connection conn;
			conn=DbConnect.getDBconnection();
			
			try{
				PreparedStatement pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, sno);
				pstmt.setString(2, sname);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next()){
					Apartment2 u=new Apartment2();
					u.setSno(rs.getString("sno"));
					u.setSname(rs.getString("sname"));
					u.setShouldpay(rs.getFloat("shouldpay"));
					u.setPaid(rs.getFloat("paid"));
					u.setSinstitution(rs.getString("sinstitution"));
					u.setSgrade(rs.getString("sgrade"));
					u.setSclasss(rs.getString("sclasss"));
					DbConnect.closeDB(conn, pstmt, rs);
					 return u;	
				}else
				 {return null;}
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
	}
	
	public Apartment2 querybysno(String sno){//简单查询
		
		String sql="select * from apartment where sno=?";
			Connection conn;
			conn=DbConnect.getDBconnection();
			
			try{
				PreparedStatement pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, sno);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next()){
					Apartment2 u=new Apartment2();
					u.setSno(rs.getString("sno"));
					u.setSname(rs.getString("sname"));
					u.setShouldpay(rs.getFloat("shouldpay"));
					u.setPaid(rs.getFloat("paid"));					
					u.setSinstitution(rs.getString("sinstitution"));
					u.setSgrade(rs.getString("sgrade"));
					u.setSclasss(rs.getString("sclasss"));  
					DbConnect.closeDB(conn, pstmt, rs);
					 return u;	
				}else
				 {return null;}
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
	}
	public boolean update(Apartment2 u){
		
		try{
			Connection conn=DbConnect.getDBconnection();
			String sql="update apartment set sname=?, shouldpay=?,paid=?,sinstitution=?,sgrade=?,sclasss=? where sno=?";
					 
			PreparedStatement  ps=conn.prepareStatement(sql);			
			
			ps.setString(1,u.getSname());
			ps.setFloat(2, u.getShouldpay());
			ps.setFloat(3,u.getPaid() );
			ps.setString(4, u.getSinstitution());
			ps.setString(5, u.getSgrade());
			ps.setString(6, u.getSclasss());
			ps.setString(7, u.getSno());
			
			int n=ps.executeUpdate();
			System.out.println("update:n="+n);
			 
			DbConnect.closeDB(conn, ps, null);
			}catch(Exception e){
				//e.printStackTrace();
				return false;
			}
			return true;
	}
	
	public List<Apartment2> vaguequerybysinstitution(String sinstitution){//模糊查询
		String sql="select * from apartment where sinstitution Like ?";
		Connection conn;
		conn=DbConnect.getDBconnection();
		List<Apartment2> lp=new  ArrayList<Apartment2>();
		
		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, "%"+sinstitution+"%");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Apartment2 u=new Apartment2();
				u.setSno(rs.getString("sno"));
				u.setSname(rs.getString("sname"));
				u.setShouldpay(rs.getFloat("shouldpay"));
				u.setPaid(rs.getFloat("paid"));
				u.setSinstitution(rs.getString("sinstitution"));
				u.setSgrade(rs.getString("sgrade"));
				u.setSclasss(rs.getString("sclasss"));
				lp.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		return lp;
	}
	public List<Apartment2> querybysgrade(String sgrade){
		String sql="select * from apartment where sgrade=?";
		Connection conn;
		conn=DbConnect.getDBconnection();
		List<Apartment2> lp=new  ArrayList<Apartment2>();
		
		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sgrade);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Apartment2 u=new Apartment2();
				u.setSno(rs.getString("sno"));
				u.setSname(rs.getString("sname"));
				u.setShouldpay(rs.getFloat("shouldpay"));
				u.setPaid(rs.getFloat("paid"));
				u.setSinstitution(rs.getString("sinstitution"));
				u.setSgrade(rs.getString("sgrade"));
				u.setSclasss(rs.getString("sclasss"));
				lp.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		return lp;
	}
	public List<Apartment2> querybysclass(String sclasss){
		String sql="select * from apartment where sclasss=?";
		Connection conn;
		conn=DbConnect.getDBconnection();
		List<Apartment2> lp=new  ArrayList<Apartment2>();
		
		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, sclasss);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Apartment2 u=new Apartment2();
				u.setSno(rs.getString("sno"));
				u.setSname(rs.getString("sname"));
				u.setShouldpay(rs.getFloat("shouldpay"));
				u.setPaid(rs.getFloat("paid"));
				u.setSinstitution(rs.getString("sinstitution"));
				u.setSgrade(rs.getString("sgrade"));
				u.setSclasss(rs.getString("sclasss"));
				lp.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		return lp;
	}
}
