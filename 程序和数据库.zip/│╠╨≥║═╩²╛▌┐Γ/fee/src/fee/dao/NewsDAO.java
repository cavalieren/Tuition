package fee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import fee.bean.News;
import fee.util.DbConnect;

public class NewsDAO {
	
	public boolean save(News news){ 
		String saveSql="insert into news(content,time) values(?,?)";
		PreparedStatement ps;
		Connection conn;
		
		try{
			conn=DbConnect.getDBconnection();
			ps=conn.prepareStatement(saveSql);
			ps.setString(1,news.getContent());
			ps.setString(2,news.getTime());

			int n=ps.executeUpdate();
			System.out.println("save:n="+n);
		}catch(Exception e){
			//e.printStackTrace();
			System.out.println("student");
			return false;
		}
		return true;
	}
	public List<News> queryAllNews(){  
		String sql="select * from news";
		Connection conn;
		List<News> ln=new  ArrayList<News>();
		conn=DbConnect.getDBconnection();
		
		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				News n=new News();
				n.setId(rs.getInt("id"));
				n.setContent(rs.getString("content"));
				n.setTime(rs.getString("time"));
				ln.add(n);	
			}
			DbConnect.closeDB(conn, pstmt, rs);
			
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		return ln;
	}
    public boolean delete(Integer id){ 
		
		try{
			String sql="delete from news where id=?";
			Connection conn=DbConnect.getDBconnection();
			PreparedStatement ps=conn.prepareStatement(sql);	
			ps.setInt(1,id);
			int n1=ps.executeUpdate();
			DbConnect.closeDB(conn, ps, null);
			System.out.println("delete:n="+n1);
		}catch(Exception e){
			return false;
		}
		return true;
	}	
}
