package fee.controller;

import fee.bean.News;
import fee.dao.NewsDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/NewsController")
public class NewsController extends HttpServlet{

private static final long serialVersionUID = 1L;
    
    public NewsController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String command=request.getParameter("action");
		int com=0;
		if(command.equals("save")) com=0;
		else if(command.equals("query")) com=1;
		else if(command.equals("delete")) com=2;
		else if(command.equals("query1")) com=3;
		
		switch(com){
			case 0:save(request,response);break;
			case 1:query(request,response);break;
			case 2:delete(request,response);break;
			case 3:query1(request,response);break;
			
		}
	}
	private void save(HttpServletRequest request,HttpServletResponse response) 
			throws ServletException, IOException
	{
		 try{
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html");
			String news=request.getParameter("news");
			news=new String(news.getBytes("iso-8859-1"),"utf-8");
			System.out.println("news"+news);
			SimpleDateFormat sdft=new SimpleDateFormat("yyyy-MM-dd HH:mm");
			String date=sdft.format(new Date());
			
			News n=new News();
			n.setContent(news);
			n.setTime(date);
			NewsDAO nd=new NewsDAO();
			if(nd.save(n)){	
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out=response.getWriter();
				out.println("<script type='text/javascript'> alert('添加成功！');"
						+ "window.location.href='m_right.jsp'</script>");
				
			}else{
				request.setAttribute("error", "添加失败");
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
				
		 }catch(Exception e){
			 e.printStackTrace();
		 }
	}
	private void query(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException{
		 try{
			 NewsDAO nd=new NewsDAO();
		request.setAttribute("allnews", nd.queryAllNews());
		 request.getRequestDispatcher("manager_show_news.jsp").forward(request, response);
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		}
	private void delete(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException{ 
		 try{
			 int id=Integer.parseInt(request.getParameter("id"));
			 NewsDAO nd=new NewsDAO();
			 if(nd.delete(id)){	
					response.setContentType("text/html;charset=utf-8");
					PrintWriter out=response.getWriter();
					out.println("<script type='text/javascript'> alert('删除成功！');"
							+ "window.location.href='m_right.jsp'</script>");
					
				}else{
					request.setAttribute("error", "删除失败");
					request.getRequestDispatcher("error.jsp").forward(request, response);
				}
					
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		}
	private void query1(HttpServletRequest request,HttpServletResponse response)
	{
		 try{
			 NewsDAO nd=new NewsDAO();
		request.setAttribute("allnews", nd.queryAllNews());
		 request.getRequestDispatcher("placard.jsp").forward(request, response);
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		}
}
