package fee.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fee.bean.Tuition1;
import fee.dao.TuitionDAO;

@WebServlet("/TuitionController")

public class TuitionController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private TuitionDAO ud;

	public TuitionController() {
		ud = new TuitionDAO();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getParameter("action");
		int com = 0;
		if (command.equals("add"))
			com = 0;		
		if (command.equals("query_tuition"))
			com = 1;
		if (command.equals("findbynoname"))
			com = 2;		
		if (command.equals("delete"))
			com = 3;
		if (command.equals("updatetuition"))
			com = 4;
		if (command.equals("updatetuition1"))
			com = 5;
		if (command.equals("findbysno"))
			com = 6;
		if (command.equals("vaguefindbysinstitution"))
			com = 7;
		if (command.equals("findbysgrade"))
			com = 8;
		if (command.equals("findbysclass"))
			com = 9;
		if (command.equals("findbysgrade1"))
			com = 10;
		
		
		
		
		switch (com) {
		case 0:
			add(request, response);
			break;
		case 1:
			query_tuition(request, response);
			break;
		case 2:
			findbynoname(request, response);
			break;		
		case 3:
			delete(request, response);
			break;
		case 4:
			updatetuition(request, response);
			break;		
		case 5:
			updatetuition1(request, response);
			break;
		case 6:
			findbysno(request, response);
			break;
		case 7:
			vaguefindbysinstitution(request,response);
			break;
		case 8:
			findbysgrade(request,response);
			break;		
		case 9:
			findbysclass(request,response);
			break;
		case 10:
			findbysgrade1(request,response);
			break;
		}
		

	}
	
	public void updatetuition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			request.setCharacterEncoding("UTF-8");
			String sno = request.getParameter("sno");
			sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
			//int sno=Integer.parseInt(request.getParameter("sno"));
			TuitionDAO pd=new TuitionDAO();
			Tuition1 p=new Tuition1();
			p=pd.querybysno(sno);
			request.setAttribute("tuition", p);
			request.getRequestDispatcher("t_update.jsp").forward(request, response);
		}catch(Exception e){
			
		}
	}
	
	public void updatetuition1(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			request.setCharacterEncoding("UTF-8");
			TuitionDAO pd=new TuitionDAO();
			Tuition1 p=new Tuition1();
			String sno = request.getParameter("sno");
			sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
			//int sno=Integer.parseInt(request.getParameter("sno"));
			p.setSno(sno);
			
			String sname=request.getParameter("sname");
			sname=new String(sname.getBytes("iso-8859-1"),"utf-8");
			
			
			float shouldpay=Float.parseFloat(request.getParameter("shouldpay"));
			float paid=Float.parseFloat(request.getParameter("paid"));
			
			String sinstitution = request.getParameter("sinstitution");
			sinstitution = new String(sinstitution.getBytes("iso-8859-1"),
					"utf-8");

			String sgrade = request.getParameter("sgrade");
			sgrade = new String(sgrade.getBytes("iso-8859-1"), "utf-8");

			String sclasss = request.getParameter("sclasss");
			sclasss = new String(sclasss.getBytes("iso-8859-1"), "utf-8");

					
			p.setSname(sname);
			p.setShouldpay(shouldpay);
			p.setPaid(paid);
			p.setSinstitution(sinstitution);
			p.setSgrade(sgrade);
			p.setSclasss(sclasss);
			
    			if(pd.update(p)){
    			response.setContentType("text/html;charset=utf-8");
				PrintWriter out=response.getWriter();
				out.println("<script type='text/javascript'> alert('修改成功');history.go(-2);</script>");
				out.close();
    			
    		}
    			else{
    				response.setContentType("text/html;charset=utf-8");
    				PrintWriter out=response.getWriter();
    				out.println("<script type='text/javascript'> alert('修改成功');window.location.href='t_right.jsp';</script>");
    				out.close();
    			} 
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	private void findbysclass(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sclasss = new String(request.getParameter("sclasss")
				.getBytes("ISO8859-1"), "UTF-8");

		try {
			request.setAttribute("findbysclass",
					ud.querybysclass(sclasss));
			request.setAttribute("sclasss", sclasss);
			List<Tuition1> lp = new ArrayList<Tuition1>();
			lp = (List<Tuition1>) request.getAttribute("findbysclass");
			if (lp.size() == 0) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('未找到！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else {
				request.getRequestDispatcher("show2_feefindbysclass.jsp")
						.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void findbysgrade1(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String sgrade=request.getParameter("sgrade");
		
		try{
			sgrade=new String(sgrade.getBytes("ISO8859-1"),"UTF-8");
		 
		   request.setAttribute("findbysgrade1", ud.querybysgrade(sgrade));
		
		   request.setAttribute("sgrade", sgrade);
		
		   request.getRequestDispatcher("m_tuition_grade.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		private void findbysgrade(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			String sgrade = new String(request.getParameter("sgrade")
					.getBytes("ISO8859-1"), "UTF-8");

			try {
				request.setAttribute("findbysgrade",
						ud.querybysgrade(sgrade));
				request.setAttribute("sgrade", sgrade);
				List<Tuition1> lp = new ArrayList<Tuition1>();
				lp = (List<Tuition1>) request.getAttribute("findbysgrade");
				if (lp.size() == 0) {
					response.setContentType("text/html;charset=utf-8");
					PrintWriter out = response.getWriter();
					out.println("<html>");
					out.println("<body>");
					out.println("<script type='text/javascript'> alert('未找到！');"
							+ "history.go(-1);</script>");
					out.println("</body>");
					out.println("</html>");
					out.close();
				} else {
					request.getRequestDispatcher("show2_feefindbysgrade.jsp")
							.forward(request, response);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	private void vaguefindbysinstitution(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sinstitution = new String(request.getParameter("sinstitution")
				.getBytes("ISO8859-1"), "UTF-8");

		try {
			request.setAttribute("vaguefindbysinstitution",
					ud.vaguequerybysinstitution(sinstitution));
			request.setAttribute("sinstitution", sinstitution);
			List<Tuition1> lp = new ArrayList<Tuition1>();
			lp = (List<Tuition1>) request.getAttribute("vaguefindbysinstitution");
			if (lp.size() == 0) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('未找到！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else {
				request.getRequestDispatcher("show2_feefindbysinstitution.jsp")
						.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void findbysno(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sno = request.getParameter("sno");
		sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
		//Integer sno = Integer.parseInt(request.getParameter("sno"));

		try {

			request.setAttribute("findbysno", ud.querybysno(sno));
			Tuition1 u = (Tuition1) request.getAttribute("findbysno");
			if (u == null) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('没有找到！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else
				request.getRequestDispatcher("tuition_stusearch2.jsp").forward(request,
						response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	private void add(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
			try {
				request.setCharacterEncoding("UTF-8");
				String sno = request.getParameter("sno");
				sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
				//int sno = Integer.parseInt(request.getParameter("sno"));
				String sname = new String(request.getParameter("sname").getBytes("iso-8859-1"), "utf-8");
				Float shouldpay = Float.parseFloat(request.getParameter("shouldpay"));
				Float paid = Float.parseFloat(request.getParameter("paid"));
				String sinstitution = new String(request.getParameter("sinstitution").getBytes("iso-8859-1"), "utf-8");
				String sgrade = new String(request.getParameter("sgrade").getBytes("iso-8859-1"), "utf-8");
				String sclasss = new String(request.getParameter("sclasss").getBytes("iso-8859-1"), "utf-8");

				
				Tuition1 p = new Tuition1();
				p.setSno(sno);
				p.setSname(sname);
				p.setShouldpay(shouldpay);
				p.setPaid(paid);
				p.setSinstitution(sinstitution);
				p.setSgrade(sgrade);
				p.setSclasss(sclasss);
				TuitionDAO cdao = new TuitionDAO();
				if (sno.length()!=11) {
					response.setContentType("text/html;charset=utf-8");
					PrintWriter out = response.getWriter();
					out.println("<html>");
					out.println("<body>");
					out.println("<script type='text/javascript'> alert('学号长度不对，请检查！');"
							+ "history.go(-1);</script>");
					out.println("</body>");
					out.println("</html>");
					out.close();

				}
				else if (cdao.save(p)) {
					response.setContentType("text/html;charset=utf-8");
					PrintWriter out = response.getWriter();
					out.println("<script type='text/javascript'> alert('添加成功');"
							+ "window.location.href='m_right.jsp';</script>");
					out.close();

					// request.getRequestDispatcher("m-right.jsp").forward(request,
					// response);;
				} else {
					request.setAttribute("error", "添加失败");
					request.getRequestDispatcher("error.jsp").forward(request,
							response);
				}

			} catch (Exception e) {

			}

	}
	
	//查询所有
	private void query_tuition(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

			try {
				request.setAttribute("query_tuition", ud.queryAllTuition());
				request.getRequestDispatcher("m_tuition_all.jsp").forward(request,
						response);
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

	private void findbynoname(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String sno = request.getParameter("sno");
		sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
		//Integer sno = Integer.parseInt(request.getParameter("sno"));
		String sname = new String(request.getParameter("sname").getBytes("iso-8859-1"), "utf-8");

		try {

			request.setAttribute("findbynoname", ud.querybynoname(sno, sname));
			Tuition1 u = (Tuition1) request.getAttribute("findbynoname");
			if (u == null) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('没有找到！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else
				request.getRequestDispatcher("tuition_search2.jsp").forward(request,
						response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		try {
			//int sno = Integer.parseInt(request.getParameter("sno"));
			request.setCharacterEncoding("UTF-8");
			String sno = request.getParameter("sno");
			sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
			TuitionDAO sdao = new TuitionDAO();
			Tuition1 s = new Tuition1();
			s = sdao.querybysno(sno);
			if (s.getSno().equals(sno) ) {
				sdao.delete(s);
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script type='text/javascript'> alert('删除成功');"
						+ "history.go(-1);</script>");
				out.close();
			}

			else {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script type='text/javascript'> alert('删除失败');history.go(-1);</script>");
				out.close();

			}
		} catch (Exception e) {

		}

	}
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
