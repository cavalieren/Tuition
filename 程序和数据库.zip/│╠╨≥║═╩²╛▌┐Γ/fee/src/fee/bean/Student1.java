package fee.bean;

public class Student1 {
	
	private String sno;
	private String sname;
	private String spassword;
	private String sidcard;//身份证号码
	private String sbankcard;//银行卡号码
	private String sinstitution;//院系
	private String sgrade;//年级
	private String sclasss;//班级
	
	
	
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSpassword() {
		return spassword;
	}
	public void setSpassword(String spassword) {
		this.spassword = spassword;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSidcard() {
		return sidcard;
	}
	public void setSidcard(String sidcard) {
		this.sidcard = sidcard;
	}
	public String getSbankcard() {
		return sbankcard;
	}
	public void setSbankcard(String sbankcard) {
		this.sbankcard = sbankcard;
	}
	public String getSinstitution() {
		return sinstitution;
	}
	public void setSinstitution(String sinstitution) {
		this.sinstitution = sinstitution;
	}
	public String getSgrade() {
		return sgrade;
	}
	public void setSgrade(String sgrade) {
		this.sgrade = sgrade;
	}
	public String getSclasss() {
		return sclasss;
	}
	public void setSclasss(String sclasss) {
		this.sclasss = sclasss;
	}
	
}
