package fee.bean;

public class Tuition1 {//学费
	
	
	private String sno;
	private String sname;
	private Float shouldpay;
	private Float paid;
	private String sinstitution;
	private String sgrade;
	private String sclasss;
	
	
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	public Float getShouldpay() {
		return shouldpay;
	}
	public void setShouldpay(Float shouldpay) {
		this.shouldpay = shouldpay;
	}
	public String getSinstitution() {
		return sinstitution;
	}
	public void setSinstitution(String sinstitution) {
		this.sinstitution = sinstitution;
	}
	public String getSgrade() {
		return sgrade;
	}
	public void setSgrade(String sgrade) {
		this.sgrade = sgrade;
	}
	public String getSclasss() {
		return sclasss;
	}
	public void setSclasss(String sclasss) {
		this.sclasss = sclasss;
	}
	public Float getPaid() {
		return paid;
	}
	public void setPaid(Float paid) {
		this.paid = paid;
	}
	
	
	
	
}
