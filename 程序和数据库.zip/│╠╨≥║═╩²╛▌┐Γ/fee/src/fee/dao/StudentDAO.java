package fee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import fee.bean.Student1;
import fee.util.DbConnect;

public class StudentDAO {
	
	public boolean save(Student1 stu) {
		String saveSql="insert into student(sno,sname,spassword,sidcard,sbankcard,sinstitution,sgrade,sclasss) values(?,?,?,?,?,?,?,?)";
		PreparedStatement ps;
		Connection conn;
		
		try{
			conn=DbConnect.getDBconnection();
			ps=conn.prepareStatement(saveSql);
			ps.setString(1,stu.getSno());
			ps.setString(2,stu.getSname());
			ps.setString(3,stu.getSpassword());
			ps.setString(4,stu.getSidcard() );
			ps.setString(5,stu.getSbankcard());
			ps.setString(6,stu.getSinstitution());
			ps.setString(7,stu.getSgrade());
			ps.setString(8,stu.getSclasss());
			int n=ps.executeUpdate();
			System.out.println("save:n="+n);
		}catch(Exception e){
			//e.printStackTrace();
			return false;
		}
		return true;

	}
	
	public List<Student1> queryAllStudent(){//学生个人信息管理，可以查看密码
 		String sql="select * from student";
 		Connection conn=DbConnect.getDBconnection();
 		ArrayList<Student1> alu=new ArrayList<Student1>();
 		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Student1 u=new Student1();
				u.setSno(rs.getString("sno"));
				u.setSname(rs.getString("sname"));
				u.setSpassword(rs.getString("spassword"));
				u.setSidcard(rs.getString("sidcard"));
				u.setSbankcard(rs.getString("sbankcard"));
				u.setSinstitution(rs.getString("sinstitution"));
				u.setSgrade(rs.getString("sgrade"));
				u.setSclasss(rs.getString("sclasss"));
				alu.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);
			return alu;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}	
 	}
	
	public boolean delete(Student1 s){ 
		
		try{
			String sql="delete from student where sno=?";
			Connection conn=DbConnect.getDBconnection();
			PreparedStatement ps=conn.prepareStatement(sql);	
			ps.setString(1,s.getSno() );
			int n=ps.executeUpdate();
			DbConnect.closeDB(conn, ps, null);
			System.out.println("delete:n="+n);
		}catch(Exception e){
			return false;
		}
		return true;
	}	
	public boolean update(Student1 u){
		
		try{
			Connection conn=DbConnect.getDBconnection();
			String sql="update student set sname=?,spassword=?,sidcard=?,sbankcard=?,sinstitution=?,sgrade=?,sclasss=? where sno=?";					 
			PreparedStatement  ps=conn.prepareStatement(sql);			
			ps.setString(1,u.getSname());
			ps.setString(2,u.getSpassword());
			ps.setString(3,u.getSidcard());
			ps.setString(4,u.getSbankcard());
			ps.setString(5,u.getSinstitution());
			ps.setString(6,u.getSgrade());
			ps.setString(7,u.getSclasss());
			ps.setString(8, u.getSno());
			int n=ps.executeUpdate();
			System.out.println("update:n="+n);
			 
			DbConnect.closeDB(conn, ps, null);
			}catch(Exception e){
				//e.printStackTrace();
				return false;
			}
			return true;
	}
	public Student1 querybynoname(String sno,String sname){//组合查询学生信息
		
		String sql="select * from student where sno=? and sname=?";
			Connection conn;
			conn=DbConnect.getDBconnection();
			
			try{
				PreparedStatement pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, sno);
				pstmt.setString(2, sname);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next()){
					Student1 u=new Student1();
					u.setSno(rs.getString("sno"));
					u.setSname(rs.getString("sname"));
					u.setSpassword(rs.getString("spassword"));
					u.setSidcard(rs.getString("sidcard"));
					u.setSbankcard(rs.getString("sbankcard"));
					u.setSinstitution(rs.getString("sinstitution"));
					u.setSgrade(rs.getString("sgrade"));
					u.setSclasss(rs.getString("sclasss"));
					  
					DbConnect.closeDB(conn, pstmt, rs);
					 return u;	
				}else
				 {return null;}
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
	}
	
	public List<Student1> querybysgrade(String sgrade){//简单查询学生信息
		
		String sql="select * from student where sgrade=? order by sno";
			Connection conn;
			conn=DbConnect.getDBconnection();
			List<Student1> lp=new  ArrayList<Student1>();

			try{
				PreparedStatement pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, sgrade);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()){
					Student1 u=new Student1();
					u.setSno(rs.getString("sno"));
					u.setSname(rs.getString("sname"));
					u.setSpassword(rs.getString("spassword"));
					u.setSidcard(rs.getString("sidcard"));
					u.setSbankcard(rs.getString("sbankcard"));
					u.setSinstitution(rs.getString("sinstitution"));
					u.setSgrade(rs.getString("sgrade"));
					u.setSclasss(rs.getString("sclasss"));
					lp.add(u);	
				}
				DbConnect.closeDB(conn, pstmt, rs);	
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
			return lp;
	}
	public List<Student1> querybysclass(String sclasss){//简单查询学生信息
		
		String sql="select * from student where sclasss=? order by sno";
			Connection conn;
			conn=DbConnect.getDBconnection();
			List<Student1> lp=new  ArrayList<Student1>();

			try{
				PreparedStatement pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, sclasss);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()){
					Student1 u=new Student1();
					u.setSno(rs.getString("sno"));
					u.setSname(rs.getString("sname"));
					u.setSpassword(rs.getString("spassword"));
					u.setSidcard(rs.getString("sidcard"));
					u.setSbankcard(rs.getString("sbankcard"));
					u.setSinstitution(rs.getString("sinstitution"));
					u.setSgrade(rs.getString("sgrade"));
					u.setSclasss(rs.getString("sclasss"));
					lp.add(u);	
				}
				DbConnect.closeDB(conn, pstmt, rs);	
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
			return lp;
	}
	public List<Student1> vaguequerybysinstitution(String sinstitution){//模糊查询学生信息
		String sql="select * from student where sinstitution Like ? order by sno";
		Connection conn;
		conn=DbConnect.getDBconnection();
		List<Student1> lp=new  ArrayList<Student1>();
		
		try{
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, "%"+sinstitution+"%");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Student1 u=new Student1();
				u.setSno(rs.getString("sno"));
				u.setSname(rs.getString("sname"));
				u.setSpassword(rs.getString("spassword"));
				u.setSidcard(rs.getString("sidcard"));
				u.setSbankcard(rs.getString("sbankcard"));
				u.setSinstitution(rs.getString("sinstitution"));
				u.setSgrade(rs.getString("sgrade"));
				u.setSclasss(rs.getString("sclasss"));
				lp.add(u);	
			}
			DbConnect.closeDB(conn, pstmt, rs);	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		return lp;
	}

	public Student1 querybysname(String sname){//简单查询学生信息
		
		String sql="select * from student where sname=?";
			Connection conn;
			conn=DbConnect.getDBconnection();
			
			try{
				PreparedStatement pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, sname);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next()){
					Student1 u=new Student1();
					u.setSno(rs.getString("sno"));
					u.setSname(rs.getString("sname"));
					u.setSpassword(rs.getString("spassword"));
					u.setSidcard(rs.getString("sidcard"));
					u.setSbankcard(rs.getString("sbankcard"));
					u.setSinstitution(rs.getString("sinstitution"));
					u.setSgrade(rs.getString("sgrade"));
					u.setSclasss(rs.getString("sclasss"));
					  
					DbConnect.closeDB(conn, pstmt, rs);
					 return u;	
				}else
				 {return null;}
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
	}
	public Student1 querybysno(String sno){//简单查询学生信息
		
		String sql="select * from student where sno=?";
			Connection conn;
			conn=DbConnect.getDBconnection();
			
			try{
				PreparedStatement pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, sno);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next()){
					Student1 u=new Student1();
					u.setSno(rs.getString("sno"));
					u.setSname(rs.getString("sname"));
					u.setSpassword(rs.getString("spassword"));
					u.setSidcard(rs.getString("sidcard"));
					u.setSbankcard(rs.getString("sbankcard"));
					u.setSinstitution(rs.getString("sinstitution"));
					u.setSgrade(rs.getString("sgrade"));
					u.setSclasss(rs.getString("sclasss"));
					  System.out.println("querybysno");
					DbConnect.closeDB(conn, pstmt, rs);
					 return u;	
				}else
				 {return null;}
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
	}
	
}
