package fee.filter;

import fee.bean.Student1;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Filter1 implements Filter {

    public Filter1() {
        
    }
	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletResponse res=(HttpServletResponse)response;
		HttpServletRequest req=(HttpServletRequest)request;
		HttpSession session=req.getSession();
		String path=req.getContextPath();
		Student1 s=new Student1();
		s=(Student1)session.getAttribute("student");
		if(s==null){
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out=response.getWriter();
			out.println("<script type='text/javascript'> alert('你还没登录，请先登录，才能执行此操作！');"
					+ "window.location.href='login.jsp';</script>");
			 out.close();
			 //res.sendRedirect(path+"/login.jsp"); 
		}else{
			chain.doFilter(request,response);
		}
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
