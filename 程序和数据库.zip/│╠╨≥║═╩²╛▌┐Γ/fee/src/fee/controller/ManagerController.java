package fee.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import fee.bean.Manager;
import fee.dao.ManagerDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * 
 * @author Administrator
 *
 */
@WebServlet("/ManagerController")
public class ManagerController extends HttpServlet{

	private static final long serialVersionUID = 1L;
    private ManagerDAO mdao;   
    
    public ManagerController() {
    	mdao=new ManagerDAO();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String command=request.getParameter("action");
		int com=0;
		//if(command.equals("regist_manager")) com=0;
		if(command.equals("login_manager")) com=1;
		else if(command.equals("logout_manager")) com=2;
		else if(command.equals("query_manager")) com=3;
		else if(command.equals("add_manager")) com=4;
		else if(command.equals("delete_manager")) com=5;
		
		switch(com){
			//case 0:regist_manager(request,response);break;
			case 1:login_manager(request,response);break;
			case 2:logout_manager(request,response);break;
			case 3:query_manager(request,response);break;
			case 4:add_manager(request,response);break;
			case 5:delete_manager(request,response);break;
		}
	}
    private void delete_manager(HttpServletRequest request,
			HttpServletResponse response) {
    	try{
			int id=Integer.parseInt(request.getParameter("id"));
			request.setCharacterEncoding("UTF-8");
			ManagerDAO cdao=new ManagerDAO();
			Manager c=new Manager();
			c=cdao.queryById(id);		
    		if(c.getId()==id){
    			cdao.delete(c);
    			response.setContentType("text/html;charset=utf-8");
				PrintWriter out=response.getWriter();
				out.println("<script type='text/javascript'> alert('删除成功');"
						+ "history.go(-1);</script>");
				out.close();
    		}
    		
    		else{
    			response.setContentType("text/html;charset=utf-8");
				PrintWriter out=response.getWriter();
				out.println("<script type='text/javascript'> alert('删除失败');"
						+ "history.go(-1);</script>");
				out.close();
				
			}
		}catch(Exception e){
			
		}
		
		
	}
	private void add_manager(HttpServletRequest request,
			HttpServletResponse response) {
		try{
			request.setCharacterEncoding("UTF-8");
			String mname=request.getParameter("mname");
			String mpassword=request.getParameter("mpassword");
			
			
			Manager p=new Manager(); 
			p.setMname(mname);
			p.setMpassword(mpassword);
			
			ManagerDAO cdao=new ManagerDAO();
			if(cdao.save(p)){
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out=response.getWriter();
				out.println("<script type='text/javascript'> alert('添加成功');"
						+ "window.location.href='m_right.jsp';</script>");
				out.close();
				
			}else{
				request.setAttribute("error", "添加失败");
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
			
		}catch(Exception e){
			
		}
	}
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
	
	public void login_manager(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String mname=new String(request.getParameter("mname").getBytes("ISO8859-1"),"UTF-8");
		String mpassword=request.getParameter("mpassword");
		//String info="";
		try{
	        HttpSession session=request.getSession();
			//List<Manager> lu;
			List<Manager> lu=new ArrayList<Manager>();
			lu=mdao.queryAllManager();
			ManagerDAO ud=new ManagerDAO();

			
			int flag=0;
			for(int i=0;i<lu.size();i++){
				String name1=lu.get(i).getMname();
				if(name1.equals(mname)&&lu.get(i).getMpassword().equals(mpassword)){
					//System.out.println("name="+name);
					//info="��½�ɹ�";
					response.setContentType("text/html;charset=utf-8");
					PrintWriter out=response.getWriter();
					//out.println("<html>");
					//out.println("<body>");
					out.println("<script type='text/javascript'> alert('登陆成功');"
							+ "window.location.href='m_main.jsp';</script>");
					//out.println("</body>");
					//out.println("</html>");
					//out.close();
					
					session.setAttribute("manager", lu.get(i));
					if(ud.queryManagerByName(mname)!=null){
						 
						 session.setAttribute("mname", ud.queryManagerByName(mname));
					}
					flag=1;
					break;
				}	
				
			}
			if(flag==0) { 
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out=response.getWriter();		
			out.println("<script type='text/javascript'> alert('登录失败');"
					+ "history.go(-1);</script>");
		//	request.setAttribute("error", info);
		//	request.getRequestDispatcher("error.jsp").forward(request, response);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	
	}
	public void logout_manager(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();;
		 session=request.getSession();      
       session.invalidate();   
       response.sendRedirect("logout.jsp");
	}
protected void query_manager(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			   request.setAttribute("query_manager", mdao.queryAllManager1());
			   request.getRequestDispatcher("manager_find.jsp").forward(request, response);
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
}
