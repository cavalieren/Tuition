package fee.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Studentlogcheck")
public class Studentlogcheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Studentlogcheck() {
        super();       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String studentid=request.getParameter("studentid");
		String studentpwd=request.getParameter("studentpwd");
		String studentcheckcode=request.getParameter("checkcode");
		String info="";
		HttpSession session=request.getSession();
		String servercheckcode=(String)session.getAttribute("checkCode");
		if(!servercheckcode.equalsIgnoreCase(studentcheckcode)){
			info="验证码不正确，请重新输入";
		/*}else if("张三".equals(studentid)&&"123".equals(studentpwd)){
			info="登陆成功";*/
		}else{
			info="用户名或密码不正确";
		}
		request.setAttribute("info", info);
		RequestDispatcher rd=request.getRequestDispatcher("login_student.jsp");
		
	}

}
