package fee.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import fee.bean.Student1;
import fee.dao.StudentDAO;

@WebServlet("/StudentController")
public class StudentController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private StudentDAO ud;

	public StudentController() {
		ud = new StudentDAO();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getParameter("action");
		int com = 0;
		if (command.equals("add"))
			com = 0;
		if (command.equals("login"))
			com = 1;
		if (command.equals("logout"))
			com = 2;
		if (command.equals("query_student"))
			com = 3;
		if (command.equals("findbynoname"))
			com = 4;
		if (command.equals("updatestudent"))
			com = 5;
		if (command.equals("updatestudent1"))
			com = 6;
		if (command.equals("vaguefindbysinstitution"))
			com = 7;
		if (command.equals("delete"))
			com = 8;
		if (command.equals("findbysgrade"))
			com = 9;
		if (command.equals("findbysclass"))
			com = 10;
		if (command.equals("logout"))
			com = 11;
		if (command.equals("mupdatestudent"))
			com = 12;
		if (command.equals("mupdatestudent1"))
			com = 13;
		if (command.equals("findbysgrade1"))
			com = 14;
		switch (com) {
		case 0:
			add(request, response);
			break;
		case 1:
			login(request, response);
			break;
		case 2:
			logout(request, response);
			break;
		case 3:
			query_student(request, response);
			break;
		case 4:
			findbynoname(request, response);
			break;
		case 5:
			updatestudent(request, response);
			break;
		case 6:
			updatestudent1(request, response);
			break;
		case 7:
			vaguefindbysinstitution(request, response);
			break;
		case 8:
			delete(request, response);
			break;
		case 9:
			findbysgrade(request, response);
			break;
		case 10:
			findbysclass(request, response);
			break;
		case 11:
			logout(request, response);
			break;
		case 12:
			mupdatestudent(request, response);
			break;
		case 13:
			mupdatestudent1(request, response);
			break;
		
		case 14:
			findbysgrade1(request, response);
			break;
		}
	}
	
	// 学生端修改个人信息:p_left通过action触发updatestudent，转到student_update_info.jsp显示修改项
			public void mupdatestudent(HttpServletRequest request,
					HttpServletResponse response) throws ServletException, IOException {
				try {
					String sno = request.getParameter("sno");
					sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
					//int sno = Integer.parseInt(request.getParameter("sno"));
					StudentDAO ud = new StudentDAO();
					Student1 u = new Student1();
					u = ud.querybysno(sno);
					request.setAttribute("u", u);
					request.getRequestDispatcher("mp_update.jsp").forward(
							request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			// 续 学生端修改个人信息：student_update_info.jsp通过action触发updatestudent1从而进行修改信息
			public void mupdatestudent1(HttpServletRequest request,
					HttpServletResponse response) throws ServletException, IOException {
				try {
					//HttpSession session = request.getSession();
					StudentDAO ud = new StudentDAO();
					Student1 u = new Student1();
					String sno = request.getParameter("sno");
					sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
					//int sno = Integer.parseInt(request.getParameter("sno"));
					u.setSno(sno);

					String sname = request.getParameter("sname");
					sname = new String(sname.getBytes("iso-8859-1"), "utf-8");

					String spassword = request.getParameter("spassword");
					spassword = new String(spassword.getBytes("iso-8859-1"), "utf-8");

					String sidcard = request.getParameter("sidcard");
					sidcard = new String(sidcard.getBytes("iso-8859-1"), "utf-8");

					String sbankcard = request.getParameter("sbankcard");
					sbankcard = new String(sbankcard.getBytes("iso-8859-1"), "utf-8");

					String sinstitution = request.getParameter("sinstitution");
					sinstitution = new String(sinstitution.getBytes("iso-8859-1"),
							"utf-8");

					String sgrade = request.getParameter("sgrade");
					sgrade = new String(sgrade.getBytes("iso-8859-1"), "utf-8");

					String sclasss = request.getParameter("sclasss");
					sclasss = new String(sclasss.getBytes("iso-8859-1"), "utf-8");

					u.setSname(sname);
					u.setSpassword(spassword);
					u.setSidcard(sidcard);
					u.setSbankcard(sbankcard);
					u.setSinstitution(sinstitution);
					u.setSgrade(sgrade);
					u.setSclasss(sclasss);
					//session.setAttribute("student", u);
					System.out.println("------------");
					if (ud.update(u)) {
						response.setContentType("textml;charset=utf-8");
						PrintWriter out = response.getWriter();
						out.println("<script type='text/javascript'> alert('SUCCESS');"
								+ "history.go(-2);</script>");
						out.close();

					} else {
						response.setContentType("textml;charset=utf-8");
						PrintWriter out = response.getWriter();
						out.println("<script type='text/javascript'> alert('error');"
								+ "window.location.href='mp_person.jsp';</script>");
						out.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			public void updatestudent(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			try {
				String sno = request.getParameter("sno");
				sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
				//int sno = Integer.parseInt(request.getParameter("sno"));
				StudentDAO ud = new StudentDAO();
				Student1 u = new Student1();
				u = ud.querybysno(sno);
				request.setAttribute("u", u);
				request.getRequestDispatcher("student_update_info.jsp").forward(
						request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void updatestudent1(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			try {
				request.setCharacterEncoding("UTF-8");
				HttpSession session = request.getSession();
				StudentDAO ud = new StudentDAO();
				Student1 u = new Student1();
				String sno = request.getParameter("sno");
				sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
				//int sno = Integer.parseInt(request.getParameter("sno"));
				u.setSno(sno);

				String sname = request.getParameter("sname");
				sname = new String(sname.getBytes("iso-8859-1"), "utf-8");

				String spassword = request.getParameter("spassword");
				spassword = new String(spassword.getBytes("iso-8859-1"), "utf-8");

				String sidcard = request.getParameter("sidcard");
				sidcard = new String(sidcard.getBytes("iso-8859-1"), "utf-8");

				String sbankcard = request.getParameter("sbankcard");
				sbankcard = new String(sbankcard.getBytes("iso-8859-1"), "utf-8");

				String sinstitution = request.getParameter("sinstitution");
				sinstitution = new String(sinstitution.getBytes("iso-8859-1"),
						"utf-8");

				String sgrade = request.getParameter("sgrade");
				sgrade = new String(sgrade.getBytes("iso-8859-1"), "utf-8");

				String sclasss = request.getParameter("sclasss");
				sclasss = new String(sclasss.getBytes("iso-8859-1"), "utf-8");

				u.setSname(sname);
				u.setSpassword(spassword);
				u.setSidcard(sidcard);
				u.setSbankcard(sbankcard);
				u.setSinstitution(sinstitution);
				u.setSgrade(sgrade);
				u.setSclasss(sclasss);
				session.setAttribute("student", u);
				if (ud.update(u)) {
					response.setContentType("textml;charset=utf-8");
					PrintWriter out = response.getWriter();
					out.println("<script type='text/javascript'> alert('SUCCESS');"
							+ "history.go(-2);</script>");
					out.close();

				} else {
					response.setContentType("textml;charset=utf-8");
					PrintWriter out = response.getWriter();
					out.println("<script type='text/javascript'> alert('error');"
							+ "window.location.href='person.jsp';</script>");
					out.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	private void findbysgrade1(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String sgrade=request.getParameter("sgrade");
		
		try{
			sgrade=new String(sgrade.getBytes("ISO8859-1"),"UTF-8");
		 
		   request.setAttribute("findbysgrade1", ud.querybysgrade(sgrade));
		
		   request.setAttribute("sgrade", sgrade);
		
		   request.getRequestDispatcher("m_student_grade.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	private void findbysclass(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		String sclasss = new String(request.getParameter("sclasss")
				.getBytes("ISO8859-1"), "UTF-8");

		try {
			request.setAttribute("findbysclass",
					ud.querybysclass(sclasss));
			request.setAttribute("sclasss", sclasss);
			List<Student1> lp = new ArrayList<Student1>();
			lp = (List<Student1>) request.getAttribute("findbysclass");
			if (lp.size() == 0) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('未找到相关学生！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else {
				request.getRequestDispatcher("show2_findbysclass.jsp")
						.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void findbysgrade(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sgrade = new String(request.getParameter("sgrade")
				.getBytes("ISO8859-1"), "UTF-8");

		try {
			request.setAttribute("findbysgrade",
					ud.querybysgrade(sgrade));
			request.setAttribute("sgrade", sgrade);
			List<Student1> lp = new ArrayList<Student1>();
			lp = (List<Student1>) request.getAttribute("findbysgrade");
			if (lp.size() == 0) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('未找到相关学生！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else {
				request.getRequestDispatcher("show2_findbysgrade.jsp")
						.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	private void vaguefindbysinstitution(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sinstitution = new String(request.getParameter("sinstitution")
				.getBytes("ISO8859-1"), "UTF-8");

		try {
			request.setAttribute("vaguefindbysinstitution",
					ud.vaguequerybysinstitution(sinstitution));
			request.setAttribute("sinstitution", sinstitution);
			List<Student1> lp = new ArrayList<Student1>();
			lp = (List<Student1>) request.getAttribute("vaguefindbysinstitution");
			if (lp.size() == 0) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('未找到相关学生！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else {
				request.getRequestDispatcher("show2_findbysinstitution.jsp")
						.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			String sno = request.getParameter("sno");
			sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
			//int sno = Integer.parseInt(request.getParameter("sno"));
			request.setCharacterEncoding("UTF-8");
			StudentDAO sdao = new StudentDAO();
			Student1 s = new Student1();
			s = sdao.querybysno(sno);
			if (s.getSno().equals(sno)) {
				sdao.delete(s);
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script type='text/javascript'> alert('删除成功');history.go(-1);</script>");
				out.close();
			}

			else {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script type='text/javascript'> alert('删除失败');history.go(-1);</script>");
				out.close();

			}
		} catch (Exception e) {

		}

	}

	private void add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String sno = request.getParameter("sno");
			sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
			//int sno = Integer.parseInt(request.getParameter("sno"));
			String sname = new String(request.getParameter("sname").getBytes("ISO8859-1"), "UTF-8");
			String spassword = new String(request.getParameter("spassword").getBytes("ISO8859-1"), "UTF-8");
			String sidcard =new String( request.getParameter("sidcard").getBytes("ISO8859-1"), "UTF-8");
			String sbankcard = new String(request.getParameter("sbankcard").getBytes("ISO8859-1"), "UTF-8");
			String sinstitution = new String(request.getParameter("sinstitution").getBytes("ISO8859-1"), "UTF-8");
			String sgrade = new String(request.getParameter("sgrade").getBytes("ISO8859-1"), "UTF-8");
			String sclasss =new String(request.getParameter("sclasss").getBytes("ISO8859-1"), "UTF-8");

			Student1 p = new Student1();
			p.setSno(sno);
			p.setSname(sname);
			p.setSpassword(spassword);
			p.setSidcard(sidcard);
			p.setSbankcard(sbankcard);
			p.setSinstitution(sinstitution);
			p.setSgrade(sgrade);
			p.setSclasss(sclasss);

			StudentDAO cdao = new StudentDAO();
			//String s= "[A-Za-z]+$";
			/*if (sno.matches(s)) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('学号中不能输入字母');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();

			}*/
			if (sno.length()!=11) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('学号长度不对，请检查！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();

			}
			
			
			else if (sidcard.length()!=18) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('身份证号长度不对，请检查！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();

			}
			else if (sbankcard.length()!=19) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('银行卡号长度不对，请检查！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();

			}
			else if (cdao.save(p)) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script type='text/javascript'> alert('添加成功');"
						+ "window.location.href='m_right.jsp';</script>");
				out.close();

				// request.getRequestDispatcher("b-right.jsp").forward(request,
				// response);;
			} else {
				request.setAttribute("error", "添加失败");
				request.getRequestDispatcher("error.jsp").forward(request,
						response);
			}

		} catch (Exception e) {

		}

	}

	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		/*String sname = new String(request.getParameter("sname").getBytes(
				"ISO8859-1"), "UTF-8");*/
		String sno = request.getParameter("sno");
		sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
		//int sno = Integer.parseInt(request.getParameter("sno"));
		String spassword = request.getParameter("spassword");
		String checkcode = request.getParameter("checkcode");

		// String info="";
		try {
			int flag = 0;
			HttpSession session = request.getSession();
			String servecheckcode = (String) session.getAttribute("checkCode");
			Student1 student = (Student1) session.getAttribute("student");

			if (student == null) {
				student = new Student1();
			}

			List<Student1> lstu = new ArrayList<Student1>();
			lstu = ud.queryAllStudent();

			if (!servecheckcode.equalsIgnoreCase(checkcode)) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('验证码不正确，请重新输入！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();

				// info="验证码不正确，请重新输入";
			} else {
				if (spassword == null) {
					response.setContentType("text/html;charset=utf-8");
					PrintWriter out = response.getWriter();
					out.println("<html>");
					out.println("<body>");
					out.println("<script type='text/javascript'> alert('请输入密码！');"
							+ "history.go(-1);</script>");
					out.println("</body>");
					out.println("</html>");
					out.close();
				} else {
					for (int i = 0; i < lstu.size(); i++) {
						String no = lstu.get(i).getSno();
						/*String name = lstu.get(i).getSname();*/
						// System.out.println("name="+no);
						// System.out.println("input  name"+sno);
						if (no.equals(sno) && lstu.get(i).getSpassword().equals(spassword)) {
							// System.out.println("name="+no);
							// info="登陆成功";
							response.setContentType("text/html;charset=utf-8");
							PrintWriter out = response.getWriter();
							out.println("<html>");
							out.println("<body>");
							out.println("<script type='text/javascript'> alert('登陆成功！');"
									+ "window.location.href='main.jsp';</script>");
							out.println("</body>");
							out.println("</html>");
							out.close();
							flag = 1;
							// if(ud.queryByNamepass(sname, password)!=null){

							// session.setAttribute("student",
							// ud.queryByNamepass(sname, password));

							session.setAttribute("student", lstu.get(i));
							StudentDAO sd = new StudentDAO();
							session.setAttribute("sno",
									sd.querybysno(sno));
							break;
						}
						// else info="用户名或密码错误";
					}

					if (flag == 0) {
						// info="用户名或密码错误";
						response.setContentType("text/html;charset=utf-8");
						PrintWriter out = response.getWriter();
						out.println("<html>");
						out.println("<body>");
						out.println("<script type='text/javascript'> alert('用户名或密码错误！');"
								+ "history.go(-1);</script>");
						out.println("</body>");
						out.println("</html>");
						out.close();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void logout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}


	// 管理端学生信息管理:查看所有学生信息
	protected void query_student(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try {
			request.setCharacterEncoding("UTF-8");
			request.setAttribute("query_student", ud.queryAllStudent());
			request.getRequestDispatcher("m_student_find.jsp").forward(request,
					response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//管理端查询：student_search1中输入查询条件，响应action中的findbynoname，跳到student_search2.jsp显示查询结果
	protected void findbynoname(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sno = request.getParameter("sno");
		sno = new String(sno.getBytes("iso-8859-1"), "utf-8");
		//Integer sno = Integer.parseInt(request.getParameter("sno"));
		String sname = request.getParameter("sname");

		try {
			sname = new String(sname.getBytes("ISO8859-1"), "UTF-8");
			request.setAttribute("findbynoname", ud.querybynoname(sno, sname));
			Student1 u = (Student1) request.getAttribute("findbynoname");
			if (u == null) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<body>");
				out.println("<script type='text/javascript'> alert('没有找到该生！');"
						+ "history.go(-1);</script>");
				out.println("</body>");
				out.println("</html>");
				out.close();
			} else
				request.getRequestDispatcher("student_search2.jsp").forward(request,
						response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void Logout(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		 HttpSession session=request.getSession();;
		 session=request.getSession();      
        session.invalidate();   
        response.sendRedirect("logout.jsp");
       
	
	}
}
